<?php $__env->startSection('content'); ?>
<div class="row py-1">
    <div class="col-lg-2">
        <div class="page-header-title">
            <h4>Dashboard</h4>
        </div>
    </div>
    <div class="col-lg-10 m-auto">
        <div class="page-header-breadcrumb">
            <ul class="breadcrumb-title">
                <li class="breadcrumb-item">
                    <a href="index.html">
                        <i class="icofont icofont-home"></i>
                    </a>
                </li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a>
                </li>
            </ul>
        </div>
    </div>
</div>

 

<!-- Reset Order Start -->
<div class="col-md-12">
    <div class="card">
        <div class="card-block">
            <h5>Reset Order</h5>
        </div>
        <div class="card-block reset-table p-t-0">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr class="text-uppercase">
                            <th>Image</th>
                            <th>Product Name</th>
                            <th>Product Code</th>
                            <th>Status</th>
                            <th>Purchased on</th>
                            <th>Price</th>
                            <th>Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><a href="#!"><img class="img-responsive" src="<?php echo e(asset('dashboard_asset/images/widget/prod1.jpg')); ?>" alt="chat-user"></a>
                            </td>
                            <td>Leisure Suit Casual</td>
                            <td>3BSD59</td>
                            <td><button type="button" class="btn btn-success btn-round">Pending</button></td>
                            <td>27 Sep 2015</td>
                            <td>$99.00</td>
                            <td>2</td>
                        </tr>
                        <tr>
                            <td><a href="#!"><img class="img-responsive" src="<?php echo e(asset('dashboard_asset/images/widget/prod4.jpg')); ?>" alt="chat-user"></a>
                            </td>
                            <td>Leisure Suit Casual</td>
                            <td>3BSD59</td>
                            <td><button type="button" class="btn btn-primary btn-round">Process</button></td>
                            <td>27 Sep 2015</td>
                            <td>$99.00</td>
                            <td>2</td>
                        </tr>
                        <tr>
                            <td><a href="#!"><img class="img-responsive" src="<?php echo e(asset('dashboard_asset/images/widget/prod2.jpg')); ?>" alt="chat-user"></a>
                            </td>
                            <td>Leisure Suit Casual</td>
                            <td>3BSD59</td>
                            <td><button type="button" class="btn btn-warning btn-round">Failed</button></td>
                            <td>27 Sep 2015</td>
                            <td>$99.00</td>
                            <td>2</td>
                        </tr>
                        <tr>
                            <td><a href="#!"><img class="img-responsive" src="<?php echo e(asset('dashboard_asset/images/widget/prod3.jpg')); ?>" alt="chat-user"></a>
                            </td>
                            <td>Leisure Suit Casual</td>
                            <td>3BSD59</td>
                            <td><button type="button" class="btn btn-primary btn-round">Process</button></td>
                            <td>27 Sep 2015</td>
                            <td>$99.00</td>
                            <td>2</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- Reset Order End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mdsoh\OneDrive\Desktop\new\new\new-project\resources\views/home.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<!-- ======================= Top Breadcrubms ======================== -->
<div class="gray py-3">
    <div class="container">
        <div class="row">
            <div class="colxl-12 col-lg-12 col-md-12">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">Support</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Shopping Cart</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<!-- ======================= Top Breadcrubms ======================== -->

<!-- ======================= Product Detail ======================== -->
<?php if(App\Models\Cart::where('customer_id', Auth::guard('customerlogin')->id())->count() == 0): ?>
<!-- ======================= Product Detail ======================== -->
<section class="middle">
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-12 col-md-10 col-lg-8 col-xl-6 text-center">

                <!-- Icon -->
                <div class="p-4 d-inline-flex align-items-center justify-content-center circle bg-light-success text-secondary mx-auto mb-4"><img width="150" src="https://static.vecteezy.com/system/resources/thumbnails/005/006/007/small/no-item-in-the-shopping-cart-click-to-go-shopping-now-concept-illustration-flat-design-eps10-modern-graphic-element-for-landing-page-empty-state-ui-infographic-icon-vector.jpg" alt=""></div>
                <!-- Heading -->
                <h2 class="mb-5 ft-bold">Your Cart is Empty!</h2>
                <a class="btn btn-dark" href="<?php echo e(url('/')); ?>">Back To Shop</a>
            </div>
        </div>

    </div>
</section>
<!-- ======================= Product Detail End ======================== -->
<?php else: ?>
<section class="middle">
    <div class="container">

        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div class="text-center d-block mb-5">
                    <h2>Shopping Cart</h2>
                </div>
            </div>
        </div>
        <div class="row justify-content-between">
            <div class="col-12 col-lg-7 col-md-12">
                <form action="<?php echo e(route('cart.update')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                <ul class="list-group list-group-sm list-group-flush-y list-group-flush-x mb-5">
                    <?php
                        $subtotal = 0;
                        ?>
                    <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <div class="row align-items-center">
                            <div class="col-3">
                                <!-- Image -->
                                <a href="product.html"><img src="<?php echo e(asset('uploads/product/preview')); ?>/<?php echo e($cart->rel_to_product->preview); ?>" alt="..." class="img-fluid"></a>
                            </div>
                            <div class="col d-flex align-items-center justify-content-between">
                                <div class="cart_single_caption pl-2">
                                    <h4 class="product_title fs-md ft-medium mb-1 lh-1"><?php echo e($cart->rel_to_product->product_name); ?></h4>
                                    <p class="mb-1 lh-1"><span class="text-dark">Size: <?php echo e($cart->rel_to_size->size_name); ?></span></p>
                                    <p class="mb-3 lh-1"><span class="text-dark">Color: <?php echo e($cart->rel_to_color->color_name); ?></span></p>
                                    <h4 class="fs-md ft-medium mb-3 lh-1">Tk: <?php echo e(number_format($cart->rel_to_product->after_discount)); ?></h4>
                                    <select class="mb-2 custom-select w-auto" name="quantity[<?php echo e($cart->id); ?>]">
                                        <option value="1"<?php echo e(($cart->quantity == 1)?'selected':''); ?>>1</option>
                                        <option value="2"<?php echo e(($cart->quantity == 2)?'selected':''); ?>>2</option>
                                        <option value="3"<?php echo e(($cart->quantity == 3)?'selected':''); ?>>3</option>
                                        <option value="4"<?php echo e(($cart->quantity == 4)?'selected':''); ?>>4</option>
                                        <option value="5"<?php echo e(($cart->quantity == 5)?'selected':''); ?>>5</option>
                                    </select>
                                </div>
                                <div class="fls_last"><a href="<?php echo e(route('cart.remove', $cart->id)); ?>" class="close_slide gray"><i class="ti-close"></i></a></div>
                            </div>
                        </div>
                    </li>
                    <?php
                        $subtotal += $cart->rel_to_product->after_discount*$cart->quantity;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div class="row justify-content-between mb-10 mb-md-0">
                    <div class="col-12 col-md-auto mfliud py-5">
                        <button class="btn stretched-link borders">Update Cart</button>
                    </div>
                </form>
                    <div class="col-12 col-md-7">
                        <!-- Coupon -->
                        <form class="mb-7 mb-md-0 py-3" action="" method="GET">
                            <?php echo csrf_field(); ?>
                            <label class="fs-sm ft-medium text-dark">Coupon code: <?php echo e(@$_GET['coupon']); ?> </label>
                            <div class="row form-row">
                                <div class="col">
                                    <input class="form-control" name="coupon" value="" type="text" placeholder="Enter coupon code*">
                                </div>
                                <div class="col-auto">
                                    <button class="btn btn-dark" type="submit">Apply</button>
                                </div>
                            </div>
                            <?php if($message): ?>
                            <div class="alert alert-warning mt-3"><?php echo e($message); ?></div>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-12 col-lg-4">
                <div class="card mb-4 gray mfliud">
                    <div class="card-body">
                        <ul class="list-group list-group-sm list-group-flush-y list-group-flush-x">
                        <li class="list-group-item d-flex text-dark fs-sm ft-regular">
                            <span>Subtotal</span> <span class="ml-auto text-dark ft-medium">Tk: <?php echo e(number_format($subtotal)); ?></span>
                        </li>
                        <li class="list-group-item d-flex text-dark fs-sm ft-regular">
                            <span>Discount</span> <span class="ml-auto text-dark ft-medium"><?php echo e(($type == 1)?'':'TK: '); ?>- <?php echo e(number_format($discount)); ?><?php echo e(($type == 1)?'%':''); ?></span>
                        </li>
                        <li class="list-group-item d-flex text-dark fs-sm ft-regular">
                            <?php
                                if($type == 1){
                                   $total= $subtotal - ($subtotal*$discount/100);
                                }
                                else {
                                    $total= $subtotal - $discount;
                                }
                            ?>
                            <span>Total</span> <span class="ml-auto text-dark ft-medium">Tk: <?php echo e(number_format($total)); ?></span>
                        </li>
                        <li class="list-group-item fs-sm text-center">
                            Shipping cost calculated at Checkout *
                        </li>
                    </ul>
                </div>
            </div>
            <?php
            $final_discount = ($type == 1)?$subtotal*$discount/100:$discount;
                session([
                    'total'=>$total,
                    'discount'=>$final_discount,
        ])
            ?>
            <a class="btn btn-block btn-dark mb-3" href="<?php echo e(route('checkout')); ?>">Proceed to Checkout</a>

            <a class="btn-link text-dark ft-medium" href="<?php echo e(url('/')); ?>">
                <i class="ti-back-left mr-2"></i> Continue Shopping
            </a>
        </div>
    </div>

</div>
</section>
<?php endif; ?>
<!-- ======================= Product Detail End ======================== -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mdsoh\OneDrive\Desktop\new\new\new-project\resources\views/frontend/cart.blade.php ENDPATH**/ ?>
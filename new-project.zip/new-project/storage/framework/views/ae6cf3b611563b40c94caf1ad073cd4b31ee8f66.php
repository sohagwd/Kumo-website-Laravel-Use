<h3>welcome to about page</h3>
<?php /**PATH C:\Users\Md.Sohag\OneDrive\Desktop\new\new-project\resources\views/about.blade.php ENDPATH**/ ?>
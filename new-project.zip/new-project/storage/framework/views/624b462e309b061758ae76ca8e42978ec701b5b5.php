<?php $__env->startSection('content'); ?>
<div class="row py-1">
    <div class="col-lg-2">
        <div class="page-header-title">
            <h4>Users</h4>
        </div>
    </div>
    <div class="col-lg-10 m-auto">
        <div class="page-header-breadcrumb">
            <ul class="breadcrumb-title">
                <li class="breadcrumb-item">
                    <a href="index.html">
                        <i class="icofont icofont-home"></i>
                    </a>
                </li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a>
                </li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('user')); ?>">Users</a>
                </li>
            </ul>
        </div>
    </div>
</div>
    <div class="">
        <div class="row">
            <div class="col-lg-12 m-auto">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">
                        <h1>User List <span style="float: right">Total User:<?php echo e($total_user); ?></span></h1>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <tr>
                                <th class="text-center">SL</th>
                                <th class="text-center">Photo</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Created at</th>
                                <th class="text-center">Action</th>
                            </tr>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td class="text-center"><?php echo e($key+1); ?></td>
                                <td class="text-center">
                                    <?php if($user->photo == null): ?>
                                    <img width="50" src="<?php echo e(Avatar::create($user->name)->toBase64()); ?>" />
                                    <?php else: ?>
                                    <img width="50" src="<?php echo e(asset('uploads/user')); ?>/<?php echo e($user->photo); ?>" />
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('profile',$user->id )); ?>"  class="tabledit-edit-button btn btn-primary waves-effect waves-light" style="float: none;margin: 5px;"><i class="icofont icofont-ui-edit"></i>Edit</a>
                                    <a href="<?php echo e(route('user.delete', $user->id)); ?>" class="tabledit-delete-button btn btn-danger waves-effect waves-light active" style="float: none;margin: 5px;"><i class="icofont icofont-ui-delete"></i>Delete</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mdsoh\OneDrive\Desktop\new\new\new-project\resources\views/admin/users/user.blade.php ENDPATH**/ ?>
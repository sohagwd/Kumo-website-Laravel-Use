<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="row py-5">
            <div class="col-lg-8">
              <div class="card">
                    <div class="card-header">
                        <h1>SubCategory List</h1>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <tr>
                                <th class="text-center">SL</th>
                                <th>Category</th>
                                <th>SubCategory</th>
                                <th class="text-center">Image</th>
                                <th class="text-center">Action</th>
                            </tr>
                            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl=>$subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td class="text-center"><?php echo e($sl+1); ?></td>
                                <td><?php echo e($subcategory->rel_to_category->category_name); ?></td>
                                <td><?php echo e($subcategory->subcategory_name); ?></td>
                                <td class="text-center"><img width="50" src="<?php echo e(asset('uploads/subcategory')); ?>/<?php echo e($subcategory->subcategory_img); ?>" class="img-fluid rounded-top" alt=""></td>
                                <td class="text-center">
                                   <a href="<?php echo e(route('edit.subcategory', $subcategory->id )); ?>" class="btn btn-success">Edit</a>
                                   <a href="<?php echo e(route('delete.category', $subcategory->id )); ?>" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card">
                    <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <div class="card-header">
                        <h1>Add SubCategory</h1>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('subcategory.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <select name="category_id" class="form-control">
                                    <option value="">--Select Category--</option>

                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="" class="form-label">SubCategory name</label>
                                <input type="text" class="form-control" name="subcategory_name">
                            </div>
                            <div class="mb-3">
                                <label for="" class="form-label">SubCategory image</label>
                                <input type="file" class="form-control" name="subcategory_img">
                            </div>
                            <div class="mb-3 pt-3">
                                <button class="btn btn-primary" type="submit">Add SubCategory</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Md.Sohag\OneDrive\Desktop\new\new-project\resources\views/admin/subcategory/subcategory.blade.php ENDPATH**/ ?>
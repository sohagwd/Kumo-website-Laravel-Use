<?php $__env->startSection('content'); ?>
<div class="row py-1">
    <div class="col-lg-2">
        <div class="page-header-title">
            <h4>Coupon</h4>
        </div>
    </div>
    <div class="col-lg-10 m-auto">
        <div class="page-header-breadcrumb">
            <ul class="breadcrumb-title">
                <li class="breadcrumb-item">
                    <a href="index.html">
                        <i class="icofont icofont-home"></i>
                    </a>
                </li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a>
                </li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('coupon')); ?>">Coupon</a>
                </li>
            </ul>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <h3>Coupon List</h3>
            </div>
            <div class="card-body">
                <table class="table tabel-striped">
                    <tr>
                        <th>SL</th>
                        <th>Coupon</th>
                        <th>Discount</th>
                        <th>Expire Date</th>
                        <th class="text-center">Action</th>
                    </tr>
                    <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($coupon->coupon_name); ?></td>
                        <td><?php echo e(($coupon->type == 1)?'':'Tk: '); ?><?php echo e(number_format($coupon->discount)); ?><?php echo e(($coupon->type == 1)?'%':''); ?></td>
                        <td><?php echo e($coupon->expire); ?></td>
                        <td class="text-center">
                            <div class="card-block post-timelines">
                                <i class="icon-options tabledit-edit-button btn btn-primary waves-effect waves-light" style="float: none;margin: 5px;" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" role="tooltip">
                                </i>
                                <div class="dropdown-menu dropdown-menu-right b-none services-list" x-placement="bottom-end" style="position: absolute; transform: translate3d(349px, 24px, 0px); top: 0px; left: 0px; will-change: transform;">
                                    <a href="#" class="tabledit-delete-button btn btn-danger waves-effect waves-light active" style="float: none;margin: 5px;"><i class="icofont icofont-ui-delete"></i>Delete</a>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">
                <h3>Add Coupon</h3>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('add.coupon')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="" class="form-label">Coupon Name</label>
                        <input type="text" name="coupon_name" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label">Discount %</label>
                        <input type="number" name="discount" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label">Expire Date</label>
                        <input type="date" name="expire" class="form-control">
                    </div>
                    <div class="mb-3">
                      <select name="type" id="" class="form-control">
                        <option value="">--Select Type--</option>
                        <option value="1">Percentage</option>
                        <option value="2">Solid Amount</option>
                      </select>
                    </div>
                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary">Add Coupon</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mdsoh\OneDrive\Desktop\new\new\new-project\resources\views/admin/coupon/coupon.blade.php ENDPATH**/ ?>
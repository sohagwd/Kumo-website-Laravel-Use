<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="row py-5">
            <div class="col-lg-8">
              <div class="card">
                    <div class="card-header">
                        <h1>Category List</h1>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <tr>
                                <th class="text-center">SL</th>
                                <th>Category</th>
                                <th>Added By</th>
                                <th class="text-center">Image</th>
                                <th class="text-center">Action</th>
                            </tr>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td class="text-center"><?php echo e($sl+1); ?></td>
                                <td><?php echo e($category->category_name); ?></td>
                                <td>
                                    <?php if(App\Models\user::where('id', $category->added_by)->exists()): ?>
                                    <?php echo e($category->rel_to_user->name); ?>

                                    <?php else: ?>
                                        Unknown
                                    <?php endif; ?></td>
                                <td class="text-center"><img width="50" src="<?php echo e(asset('uploads/category')); ?>/<?php echo e($category->category_img); ?>" class="img-fluid rounded-top" alt=""></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('edit.category', $category->id )); ?>" class="btn btn-success">Edit</a>
                                    <a href="<?php echo e(route('delete.category', $category->id )); ?>" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card">
                    <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <div class="card-header">
                        <h1>Add Category</h1>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('category.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="" class="form-label">Category name</label>
                                <input type="text" class="form-control" name="category_name">
                                <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="" class="form-label">Category image</label>
                                <input type="file" class="form-control" name="category_img">
                                <?php $__errorArgs = ['category_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 pt-3">
                                <button class="btn btn-primary" type="submit">Add Category</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 m-auto">
                <div class="card">
                    <div class="card-header">
                        <h1>Soft Deleted Category List</h1>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <tr>
                                <th class="text-center">SL</th>
                                <th>Category</th>
                                <th>Added By</th>
                                <th class="text-center">Image</th>
                                <th class="text-center">Action</th>
                            </tr>
                            <?php $__currentLoopData = $trash_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td class="text-center"><?php echo e($sl+1); ?></td>
                                <td><?php echo e($category->category_name); ?></td>
                                <td>
                                    <?php if(App\Models\user::where('id', $category->added_by)->exists()): ?>
                                    <?php echo e($category->rel_to_user->name); ?>

                                    <?php else: ?>
                                        Unknown
                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><img width="50" src="<?php echo e(asset('uploads/category')); ?>/<?php echo e($category->category_img); ?>" class="img-fluid rounded-top" alt=""></td>
                                <td class="text-center">

                                    <a href="<?php echo e(route('restore.category', $category->id )); ?>" class="btn btn-info">Restore</a>
                                    <a href="<?php echo e(route('delete.hard.category', $category->id )); ?>" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Md.Sohag\OneDrive\Desktop\new\new-project\resources\views/admin/category/category.blade.php ENDPATH**/ ?>
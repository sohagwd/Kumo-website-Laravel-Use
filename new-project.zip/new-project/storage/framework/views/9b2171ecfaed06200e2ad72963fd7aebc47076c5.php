<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 m-auto">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">
                        <h1>User List <span style="float: right">Total User:<?php echo e($total_user); ?></span></h1>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <tr>
                                <th class="text-center">SL</th>
                                <th class="text-center">Photo</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Created at</th>
                                <th class="text-center">Action</th>
                            </tr>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td class="text-center"><?php echo e($key+1); ?></td>
                                <td class="text-center">
                                    <?php if($user->photo == null): ?>
                                    <img width="50" src="<?php echo e(Avatar::create($user->name)->toBase64()); ?>" />
                                    <?php else: ?>
                                    <img width="50" src="<?php echo e(asset('uploads/user')); ?>/<?php echo e($user->photo); ?>" />
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                                <td class="text-center"><a href="<?php echo e(route('user.delete', $user->id)); ?>" class="btn btn-danger">delete</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Md.Sohag\OneDrive\Desktop\new\new-project\resources\views/admin/users/user.blade.php ENDPATH**/ ?>
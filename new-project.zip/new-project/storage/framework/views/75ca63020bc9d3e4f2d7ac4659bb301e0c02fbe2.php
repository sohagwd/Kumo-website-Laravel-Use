<?php $__env->startSection('content'); ?>
<div class="row py-1">
    <div class="col-lg-2 ">
        <div class="page-header-title">
            <h4>Product</h4>
        </div>
    </div>
    <div class="col-lg-10 m-auto">
        <div class="page-header-breadcrumb">
            <ul class="breadcrumb-title">
                <li class="breadcrumb-item">
                    <a href="index.html">
                        <i class="icofont icofont-home"></i>
                    </a>
                </li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a>
                </li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('add.product')); ?>">Product</a>
                </li>
            </ul>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h3>Product List</h3>
        </div>
        <div class="card-body">
            <table class="table table-striped">
                <tr>
                    <th>SL</th>
                    <th>Product</th>
                    <th>Brand</th>
                    <th>Price</th>
                    <th>Discount</th>
                    <th>Category</th>
                    <th>SubCategory</th>
                    <th>Preview</th>
                    <th>Thumbnails</th>
                    <th class="text-center">Action</th>
                </tr>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($product->product_name); ?></td>
                    <td><?php echo e($product->brand); ?></td>
                    <td>TK: <?php echo e(number_format($product->price)); ?></td>
                    <td><?php echo e($product->discount); ?>%</td>
                    <td><?php echo e($product->rel_to_cat->category_name); ?></td>
                    <td><?php echo e($product->rel_to_subcat->subcategory_name); ?></td>
                    <td><img width="70" src="<?php echo e(asset('uploads/product/preview/')); ?>/<?php echo e($product->preview); ?>" alt="preview"></td>
                    <td>
                        <?php $__currentLoopData = App\Models\thumbnail::where('product_id', $product->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thumbnail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img width="34" src="<?php echo e(asset('uploads/product/thumbnail/')); ?>/<?php echo e($thumbnail->thumbnail); ?>" alt="">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                        <div class="card-block post-timelines">
                            <i class="icon-options tabledit-edit-button btn btn-primary waves-effect waves-light" style="float: none;margin: 2px;" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" role="tooltip">
                            </i>
                            <div class="dropdown-menu dropdown-menu-right b-none services-list" x-placement="bottom-end" style="position: absolute; transform: translate3d(349px, 24px, 0px); top: 0px; left: 0px; will-change: transform;">
                        <a href="<?php echo e(route('inventory',$product->id)); ?>"  class="tabledit-edit-button btn btn-primary waves-effect waves-light" style="float: none;margin: 5px;"><i class="ion-clipboard"></i>Inventory</a>
                        <a href="<?php echo e(route('product.delete', $product->id)); ?>"class="tabledit-delete-button btn btn-danger waves-effect waves-light active" style="float: none;margin: 5px;"><i class="icofont icofont-ui-delete"></i>Delete</a>
                            </div>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mdsoh\OneDrive\Desktop\new\new\new-project\resources\views/admin/product/product.blade.php ENDPATH**/ ?>